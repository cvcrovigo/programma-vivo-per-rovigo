const menu = document.querySelector('#menu-mobile');
const toggle = document.querySelector('.menu-toggle');
toggle.addEventListener('click', () => {
  menu.showModal();
  toggle.setAttribute('aria-expanded', 'true');
});
menu.addEventListener('close', () => {
  toggle.setAttribute('aria-expanded', 'false');
  toggle.focus();
});
menu.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', () => menu.close());
});
