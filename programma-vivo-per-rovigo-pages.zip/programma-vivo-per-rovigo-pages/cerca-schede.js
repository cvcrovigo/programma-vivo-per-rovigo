const searchForm = document.querySelector('.ricerca-schede');
const searchInput = searchForm.querySelector('input');
const searchStatus = searchForm.querySelector('[role="status"]');
const clearSearch = searchForm.querySelector('button');

function normalize(text) {
  return text.toLocaleLowerCase('it').normalize('NFD')
    .replace(/\p{M}/gu, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

const areas = [...document.querySelectorAll('#elenco-schede .area')].map(area => {
  const areaTitle = area.querySelector('h2').textContent;
  const cards = [...area.querySelectorAll('.catalog li')].map(row => {
    const link = row.querySelector('a');
    const code = link.getAttribute('href').replace(/\.html$/, '');
    return { row, terms: normalize([link.textContent, areaTitle, code, code.replaceAll('-', '')].join(' ')) };
  });
  return { area, cards };
});

function filterCards() {
  const query = normalize(searchInput.value);
  const words = query ? query.split(' ') : [];
  let count = 0;
  for (const { area, cards } of areas) {
    let visibleCards = 0;
    for (const { row, terms } of cards) {
      const matches = words.every(word => terms.includes(word));
      row.hidden = !matches;
      if (matches) visibleCards += 1;
    }
    area.hidden = visibleCards === 0;
    count += visibleCards;
  }
  clearSearch.disabled = !searchInput.value;
  searchStatus.textContent = !query ? '' :
    count === 0 ? 'Nessuna scheda trovata.' :
    count === 1 ? '1 scheda trovata.' : count + ' schede trovate.';
}

searchForm.addEventListener('submit', event => event.preventDefault());
searchForm.addEventListener('reset', event => {
  event.preventDefault();
  searchInput.value = '';
  filterCards();
  searchInput.focus();
});
searchInput.addEventListener('input', filterCards);
filterCards();
searchForm.hidden = false;
